var sf_version = '1.29b';
var scan_date  = 'Sat Apr  3 01:27:15 2010';
var scan_seed  = '0x8231cc46';
var scan_ms    = 20344428;
