var child = [
  { 'dupe': false, 'type': 10, 'name': 'https://team7.ath.cx/', 'dir': 'c0', 'linked': 2, 'url': 'https://team7.ath.cx/', 'fetched': true, 'code': 200, 'len': 3608, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'missing': false, 'csens': true, 'child_cnt': 101, 'issue_cnt': [ 34, 1, 6, 17, 0 ] }
];
