var mime_samples = [
  { 'mime': 'application/binary', 'samples': [
    { 'url': 'https://team7.ath.cx/js/jquery.ui.combobox.js', 'dir': '_m0/0', 'linked': 2, 'len': 2429 },
    { 'url': 'https://team7.ath.cx/~test/js/jquery.ui.combobox.js', 'dir': '_m0/1', 'linked': 2, 'len': 2350 } ]
  },
  { 'mime': 'application/javascript', 'samples': [
    { 'url': 'https://team7.ath.cx/js/jquery.weekcalendar.js', 'dir': '_m1/0', 'linked': 2, 'len': 54291 },
    { 'url': 'https://team7.ath.cx/js/main.js', 'dir': '_m1/1', 'linked': 2, 'len': 7792 },
    { 'url': 'https://team7.ath.cx/php/StudentRecord.php', 'dir': '_m1/2', 'linked': 2, 'len': 86 },
    { 'url': 'https://team7.ath.cx/php/viewSchedule.php', 'dir': '_m1/3', 'linked': 2, 'len': 2362 },
    { 'url': 'https://team7.ath.cx/~test/js/jquery.weekcalendar.js', 'dir': '_m1/4', 'linked': 2, 'len': 52813 },
    { 'url': 'https://team7.ath.cx/~test/js/main.js', 'dir': '_m1/5', 'linked': 2, 'len': 7411 },
    { 'url': 'https://team7.ath.cx/~test/php/viewSchedule.php', 'dir': '_m1/6', 'linked': 2, 'len': 2285 } ]
  },
  { 'mime': 'application/xhtml+xml', 'samples': [
    { 'url': 'https://team7.ath.cx/', 'dir': '_m2/0', 'linked': 2, 'len': 3608 },
    { 'url': 'https://team7.ath.cx/css/', 'dir': '_m2/1', 'linked': 2, 'len': 378 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/', 'dir': '_m2/2', 'linked': 2, 'len': 354 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/', 'dir': '_m2/3', 'linked': 2, 'len': 1749 },
    { 'url': 'https://team7.ath.cx/export/', 'dir': '_m2/4', 'linked': 1, 'len': 205 },
    { 'url': 'https://team7.ath.cx/img/', 'dir': '_m2/5', 'linked': 2, 'len': 258 },
    { 'url': 'https://team7.ath.cx/php/', 'dir': '_m2/6', 'linked': 2, 'len': 634 },
    { 'url': 'https://team7.ath.cx/tabs/', 'dir': '_m2/7', 'linked': 2, 'len': 544 },
    { 'url': 'https://team7.ath.cx/~lp/', 'dir': '_m2/8', 'linked': 0, 'len': 206 },
    { 'url': 'https://team7.ath.cx/~test/', 'dir': '_m2/9', 'linked': 2, 'len': 3528 },
    { 'url': 'https://team7.ath.cx/~test/api/', 'dir': '_m2/10', 'linked': 2, 'len': 3055 },
    { 'url': 'https://team7.ath.cx/~test/api/annotated.html', 'dir': '_m2/11', 'linked': 2, 'len': 4283 },
    { 'url': 'https://team7.ath.cx/~test/api/classAuthentication-members.html', 'dir': '_m2/12', 'linked': 2, 'len': 5982 },
    { 'url': 'https://team7.ath.cx/~test/api/classAuthentication.html', 'dir': '_m2/13', 'linked': 2, 'len': 17660 },
    { 'url': 'https://team7.ath.cx/~test/api/classCourse.html', 'dir': '_m2/14', 'linked': 2, 'len': 12979 },
    { 'url': 'https://team7.ath.cx/~test/api/classDatabase-members.html', 'dir': '_m2/15', 'linked': 2, 'len': 4587 },
    { 'url': 'https://team7.ath.cx/~test/api/classDatabase.html', 'dir': '_m2/16', 'linked': 2, 'len': 10109 },
    { 'url': 'https://team7.ath.cx/~test/api/classStudentRecord-members.html', 'dir': '_m2/17', 'linked': 2, 'len': 5033 },
    { 'url': 'https://team7.ath.cx/~test/api/classStudentRecord.html', 'dir': '_m2/18', 'linked': 2, 'len': 12455 },
    { 'url': 'https://team7.ath.cx/~test/api/functions.html', 'dir': '_m2/19', 'linked': 2, 'len': 6983 },
    { 'url': 'https://team7.ath.cx/~test/api/search/', 'dir': '_m2/20', 'linked': 2, 'len': 1988 },
    { 'url': 'https://team7.ath.cx/~test/api/search/classes_73.html', 'dir': '_m2/21', 'linked': 2, 'len': 1136 },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_63.html', 'dir': '_m2/22', 'linked': 2, 'len': 3178 },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_67.html', 'dir': '_m2/23', 'linked': 2, 'len': 4592 },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_6c.html', 'dir': '_m2/24', 'linked': 2, 'len': 1590 },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_76.html', 'dir': '_m2/25', 'linked': 2, 'len': 2047 },
    { 'url': 'https://team7.ath.cx/~test/api/search/nomatches.html', 'dir': '_m2/26', 'linked': 2, 'len': 461 } ]
  },
  { 'mime': 'image/gif', 'samples': [
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-anim_basic_16x16.gif', 'dir': '_m3/0', 'linked': 2, 'len': 1553 },
    { 'url': 'https://team7.ath.cx/img/flexbox.gif', 'dir': '_m3/1', 'linked': 2, 'len': 1520 } ]
  },
  { 'mime': 'image/png', 'samples': [
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-bg_diagonals-thick_100_5c9ccc_40x40.png', 'dir': '_m4/0', 'linked': 2, 'len': 260 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-bg_flat_0_aaaaaa_40x100.png', 'dir': '_m4/1', 'linked': 2, 'len': 180 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-bg_glass_75_d0e5f5_1x400.png', 'dir': '_m4/2', 'linked': 2, 'len': 124 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-bg_gloss-wave_55_5c9ccc_500x100.png', 'dir': '_m4/3', 'linked': 2, 'len': 3457 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-bg_inset-hard_100_f5f8f9_1x100.png', 'dir': '_m4/4', 'linked': 2, 'len': 104 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-icons_217bc0_256x240.png', 'dir': '_m4/5', 'linked': 2, 'len': 4369 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-icons_cd0a0a_256x240.png', 'dir': '_m4/6', 'linked': 2, 'len': 4369 },
    { 'url': 'https://team7.ath.cx/css/custom-theme/images/ui-icons_f9bd01_256x240.png', 'dir': '_m4/7', 'linked': 2, 'len': 5355 },
    { 'url': 'https://team7.ath.cx/~test/api/doxygen.png', 'dir': '_m4/8', 'linked': 2, 'len': 1281 } ]
  },
  { 'mime': 'text/css', 'samples': [
    { 'url': 'https://team7.ath.cx/css/custom-theme/jquery-ui-1.8.custom.css', 'dir': '_m5/0', 'linked': 2, 'len': 31385 },
    { 'url': 'https://team7.ath.cx/css/jquery.weekcalendar.css', 'dir': '_m5/1', 'linked': 2, 'len': 2795 },
    { 'url': 'https://team7.ath.cx/css/style.css', 'dir': '_m5/2', 'linked': 2, 'len': 2990 },
    { 'url': 'https://team7.ath.cx/~test/api/doxygen.css', 'dir': '_m5/3', 'linked': 2, 'len': 6619 },
    { 'url': 'https://team7.ath.cx/~test/api/tabs.css', 'dir': '_m5/4', 'linked': 2, 'len': 1844 },
    { 'url': 'https://team7.ath.cx/~test/css/custom-theme/jquery-ui-1.8.custom.css', 'dir': '_m5/5', 'linked': 2, 'len': 30906 },
    { 'url': 'https://team7.ath.cx/~test/css/jquery.weekcalendar.css', 'dir': '_m5/6', 'linked': 2, 'len': 2601 },
    { 'url': 'https://team7.ath.cx/~test/css/style.css', 'dir': '_m5/7', 'linked': 2, 'len': 2873 } ]
  },
  { 'mime': 'text/html', 'samples': [
    { 'url': 'https://team7.ath.cx/php/Course.php', 'dir': '_m6/0', 'linked': 2, 'len': 336 },
    { 'url': 'https://team7.ath.cx/tabs/academic_record.html', 'dir': '_m6/1', 'linked': 2, 'len': 177 },
    { 'url': 'https://team7.ath.cx/tabs/browse_course.html', 'dir': '_m6/2', 'linked': 2, 'len': 1867 },
    { 'url': 'https://team7.ath.cx/tabs/view_schedule.html', 'dir': '_m6/3', 'linked': 2, 'len': 899 },
    { 'url': 'https://team7.ath.cx/~test/tabs/view_schedule.html', 'dir': '_m6/4', 'linked': 2, 'len': 860 } ]
  },
  { 'mime': 'text/plain', 'samples': [
    { 'url': 'https://team7.ath.cx/php/Authentication.php', 'dir': '_m7/0', 'linked': 2, 'len': 2 } ]
  }
];

var issue_samples = [
  { 'severity': 3, 'type': 40304, 'samples': [
    { 'url': 'https://team7.ath.cx/php/Authentication.php', 'extra': '', 'dir': '_i0/0' },
    { 'url': 'https://team7.ath.cx/php/Course.php', 'extra': '', 'dir': '_i0/1' },
    { 'url': 'https://team7.ath.cx/php/Database.php', 'extra': '', 'dir': '_i0/2' },
    { 'url': 'https://team7.ath.cx/php/StudentRecord.php', 'extra': '', 'dir': '_i0/3' },
    { 'url': 'https://team7.ath.cx/php/viewSchedule.php', 'extra': '', 'dir': '_i0/4' },
    { 'url': 'https://team7.ath.cx/tabs/academic_record.html', 'extra': '', 'dir': '_i0/5' },
    { 'url': 'https://team7.ath.cx/tabs/browse_course.html', 'extra': '', 'dir': '_i0/6' },
    { 'url': 'https://team7.ath.cx/tabs/view_schedule.html', 'extra': '', 'dir': '_i0/7' },
    { 'url': 'https://team7.ath.cx/~test/php/viewSchedule.php', 'extra': '', 'dir': '_i0/8' },
    { 'url': 'https://team7.ath.cx/~test/tabs/view_schedule.html', 'extra': '', 'dir': '_i0/9' } ]
  },
  { 'severity': 3, 'type': 40301, 'samples': [
    { 'url': 'https://team7.ath.cx/php/Authentication.php', 'extra': 'text/plain', 'dir': '_i1/0' },
    { 'url': 'https://team7.ath.cx/php/Database.php', 'extra': 'text/plain', 'dir': '_i1/1' },
    { 'url': 'https://team7.ath.cx/php/StudentRecord.php', 'extra': 'application/javascript', 'dir': '_i1/2' },
    { 'url': 'https://team7.ath.cx/php/viewSchedule.php', 'extra': 'application/javascript', 'dir': '_i1/3' },
    { 'url': 'https://team7.ath.cx/~test/php/viewSchedule.php', 'extra': 'application/javascript', 'dir': '_i1/4' } ]
  },
  { 'severity': 3, 'type': 40201, 'samples': [
    { 'url': 'https://team7.ath.cx/', 'extra': 'http://www.google.com/jsapi', 'dir': '_i2/0' },
    { 'url': 'https://team7.ath.cx/~test/', 'extra': 'http://www.google.com/jsapi', 'dir': '_i2/1' } ]
  },
  { 'severity': 2, 'type': 30602, 'samples': [
    { 'url': 'https://team7.ath.cx/php/viewSchedule.php', 'extra': '', 'dir': '_i3/0' },
    { 'url': 'https://team7.ath.cx/~test/php/viewSchedule.php', 'extra': '', 'dir': '_i3/1' } ]
  },
  { 'severity': 2, 'type': 30501, 'samples': [
    { 'url': 'https://team7.ath.cx/js/main.js', 'extra': 'http://www.youtube.com/v/kBSOhODoch0&hl=en_US&fs=1&color1=0x3a3a3a&color2=0x999999&autoplay=1', 'dir': '_i4/0' },
    { 'url': 'https://team7.ath.cx/~test/js/main.js', 'extra': 'http://www.youtube.com/v/kBSOhODoch0&hl=en_US&fs=1&color1=0x3a3a3a&color2=0x999999&autoplay=1', 'dir': '_i4/1' } ]
  },
  { 'severity': 2, 'type': 30203, 'samples': [
    { 'url': 'https://team7.ath.cx/', 'extra': 'marcandre.moreau@gmail.com', 'dir': '_i5/0' } ]
  },
  { 'severity': 2, 'type': 30202, 'samples': [
    { 'url': 'https://team7.ath.cx/', 'extra': '/C=CA/ST=Quebec/L=Boucherville/O=Awake Coding/OU=Information Technology/CN=team7.ath.cx/emailAddress=marcandre.moreau@gmail.com', 'dir': '_i6/0' } ]
  },
  { 'severity': 1, 'type': 20101, 'samples': [
    { 'url': 'https://team7.ath.cx/~test/php/Authentication.php/', 'extra': 'during node type checks', 'dir': '_i7/0' } ]
  },
  { 'severity': 0, 'type': 10901, 'samples': [
    { 'url': 'https://team7.ath.cx/css/custom-theme/jquery-ui-1.8.custom.css', 'extra': '', 'dir': '_i8/0' },
    { 'url': 'https://team7.ath.cx/~test/api/search/classes_73.html', 'extra': '', 'dir': '_i8/1' },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_63.html', 'extra': '', 'dir': '_i8/2' },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_67.html', 'extra': '', 'dir': '_i8/3' },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_6c.html', 'extra': '', 'dir': '_i8/4' },
    { 'url': 'https://team7.ath.cx/~test/api/search/functions_76.html', 'extra': '', 'dir': '_i8/5' },
    { 'url': 'https://team7.ath.cx/~test/css/custom-theme/jquery-ui-1.8.custom.css', 'extra': '', 'dir': '_i8/6' } ]
  },
  { 'severity': 0, 'type': 10803, 'samples': [
    { 'url': 'https://team7.ath.cx/css/custom-theme/jquery-ui-1.8.custom.css', 'extra': '', 'dir': '_i9/0' },
    { 'url': 'https://team7.ath.cx/css/jquery.weekcalendar.css', 'extra': '', 'dir': '_i9/1' },
    { 'url': 'https://team7.ath.cx/css/style.css', 'extra': '', 'dir': '_i9/2' },
    { 'url': 'https://team7.ath.cx/js/jquery.weekcalendar.js', 'extra': '', 'dir': '_i9/3' },
    { 'url': 'https://team7.ath.cx/js/main.js', 'extra': '', 'dir': '_i9/4' },
    { 'url': 'https://team7.ath.cx/~test/api/doxygen.css', 'extra': '', 'dir': '_i9/5' },
    { 'url': 'https://team7.ath.cx/~test/api/tabs.css', 'extra': '', 'dir': '_i9/6' },
    { 'url': 'https://team7.ath.cx/~test/css/custom-theme/jquery-ui-1.8.custom.css', 'extra': '', 'dir': '_i9/7' },
    { 'url': 'https://team7.ath.cx/~test/css/jquery.weekcalendar.css', 'extra': '', 'dir': '_i9/8' },
    { 'url': 'https://team7.ath.cx/~test/css/style.css', 'extra': '', 'dir': '_i9/9' },
    { 'url': 'https://team7.ath.cx/~test/js/jquery.weekcalendar.js', 'extra': '', 'dir': '_i9/10' },
    { 'url': 'https://team7.ath.cx/~test/js/main.js', 'extra': '', 'dir': '_i9/11' } ]
  },
  { 'severity': 0, 'type': 10801, 'samples': [
    { 'url': 'https://team7.ath.cx/js/jquery.ui.combobox.js', 'extra': 'application/binary', 'dir': '_i10/0' },
    { 'url': 'https://team7.ath.cx/~test/js/jquery.ui.combobox.js', 'extra': 'application/binary', 'dir': '_i10/1' } ]
  },
  { 'severity': 0, 'type': 10602, 'samples': [
    { 'url': 'https://team7.ath.cx/?username=gibson&password=skipfish', 'extra': '', 'dir': '_i11/0' },
    { 'url': 'https://team7.ath.cx/~test/?username=gibson&password=skipfish', 'extra': '', 'dir': '_i11/1' } ]
  },
  { 'severity': 0, 'type': 10401, 'samples': [
    { 'url': 'https://team7.ath.cx/~lp/', 'extra': '', 'dir': '_i12/0' } ]
  },
  { 'severity': 0, 'type': 10205, 'samples': [
    { 'url': 'https://team7.ath.cx/sfi9876', 'extra': '', 'dir': '_i13/0' } ]
  },
  { 'severity': 0, 'type': 10204, 'samples': [
    { 'url': 'https://team7.ath.cx/php/Authentication.php', 'extra': 'X-Powered-By', 'dir': '_i14/0' },
    { 'url': 'https://team7.ath.cx/php/Config.php', 'extra': 'X-Powered-By', 'dir': '_i14/1' },
    { 'url': 'https://team7.ath.cx/php/Course.php', 'extra': 'X-Powered-By', 'dir': '_i14/2' },
    { 'url': 'https://team7.ath.cx/php/Database.php', 'extra': 'X-Powered-By', 'dir': '_i14/3' },
    { 'url': 'https://team7.ath.cx/php/StudentRecord.php', 'extra': 'X-Powered-By', 'dir': '_i14/4' },
    { 'url': 'https://team7.ath.cx/php/viewSchedule.php', 'extra': 'X-Powered-By', 'dir': '_i14/5' },
    { 'url': 'https://team7.ath.cx/~test/php/viewSchedule.php', 'extra': 'X-Powered-By', 'dir': '_i14/6' } ]
  },
  { 'severity': 0, 'type': 10202, 'samples': [
    { 'url': 'https://team7.ath.cx/', 'extra': 'Apache/2.2.14 (Unix) mod_ssl/2.2.14 OpenSSL/0.9.8l DAV/2 PHP/5.2.11 mod_jk/1.2.28', 'dir': '_i15/0' } ]
  },
  { 'severity': 0, 'type': 10201, 'samples': [
    { 'url': 'https://team7.ath.cx/php/Authentication.php', 'extra': 'PHPSESSID', 'dir': '_i16/0' } ]
  }
];

