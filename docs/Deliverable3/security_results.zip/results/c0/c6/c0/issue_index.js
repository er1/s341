var issue = [
  { 'severity': 3, 'type': 40304, 'extra': '', 'fetched': true, 'code': 302, 'len': 2, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 3, 'type': 40301, 'extra': 'text/plain', 'fetched': true, 'code': 302, 'len': 2, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10204, 'extra': 'X-Powered-By', 'fetched': true, 'code': 302, 'len': 2, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10201, 'extra': 'PHPSESSID', 'fetched': true, 'code': 302, 'len': 18, 'decl_mime': '[none]', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i3' }
];
