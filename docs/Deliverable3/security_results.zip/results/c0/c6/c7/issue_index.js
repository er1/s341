var issue = [
  { 'severity': 3, 'type': 40304, 'extra': '', 'fetched': true, 'code': 302, 'len': 2362, 'decl_mime': 'text/html', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 3, 'type': 40301, 'extra': 'application/javascript', 'fetched': true, 'code': 302, 'len': 2362, 'decl_mime': 'text/html', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 2, 'type': 30602, 'extra': '', 'fetched': true, 'code': 302, 'len': 2362, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10204, 'extra': 'X-Powered-By', 'fetched': true, 'code': 302, 'len': 2362, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i3' }
];
