var issue = [
  { 'severity': 3, 'type': 40201, 'extra': 'http://www.google.com/jsapi', 'fetched': true, 'code': 200, 'len': 3608, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i0' },
  { 'severity': 2, 'type': 30203, 'extra': 'marcandre.moreau@gmail.com', 'fetched': false, 'error': 'Content not fetched', 'dir': 'i1' },
  { 'severity': 2, 'type': 30202, 'extra': '/C=CA/ST=Quebec/L=Boucherville/O=Awake Coding/OU=Information Technology/CN=team7.ath.cx/emailAddress=marcandre.moreau@gmail.com', 'fetched': false, 'error': 'Content not fetched', 'dir': 'i2' },
  { 'severity': 0, 'type': 10602, 'extra': '', 'fetched': true, 'code': 200, 'len': 3608, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i3' },
  { 'severity': 0, 'type': 10205, 'extra': '', 'fetched': true, 'code': 404, 'len': 205, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i4' },
  { 'severity': 0, 'type': 10202, 'extra': 'Apache/2.2.14 (Unix) mod_ssl/2.2.14 OpenSSL/0.9.8l DAV/2 PHP/5.2.11 mod_jk/1.2.28', 'fetched': true, 'code': 200, 'len': 3608, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i5' }
];
