var issue = [
  { 'severity': 2, 'type': 30501, 'extra': 'http://www.youtube.com/v/kBSOhODoch0&hl=en_US&fs=1&color1=0x3a3a3a&color2=0x999999&autoplay=1', 'fetched': true, 'code': 200, 'len': 7792, 'decl_mime': 'application/javascript', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 7792, 'decl_mime': 'application/javascript', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i1' }
];
