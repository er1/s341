var issue = [
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 54291, 'decl_mime': 'application/javascript', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i0' }
];
