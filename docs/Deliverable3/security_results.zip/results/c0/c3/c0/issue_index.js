var issue = [
  { 'severity': 0, 'type': 10801, 'extra': 'application/binary', 'fetched': true, 'code': 200, 'len': 2429, 'decl_mime': 'application/javascript', 'sniff_mime': 'application/binary', 'cset': '[none]', 'dir': 'i0' }
];
