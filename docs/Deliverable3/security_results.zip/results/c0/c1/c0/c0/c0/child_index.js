var child = [
  { 'dupe': true, 'type': 11, 'name': 'www', 'dir': 'c0', 'linked': 1, 'url': 'https://team7.ath.cx/export/home/test/team7/www/', 'fetched': true, 'code': 404, 'len': 225, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'missing': true, 'csens': false, 'child_cnt': 2, 'issue_cnt': [ 0, 0, 0, 0, 0 ] }
];
