var issue = [
  { 'severity': 1, 'type': 20101, 'extra': 'during node type checks', 'fetched': false, 'error': 'Connection error', 'dir': 'i0' }
];
