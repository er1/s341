var issue = [
  { 'severity': 0, 'type': 10204, 'extra': 'X-Powered-By', 'fetched': true, 'code': 200, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' }
];
