var child = [
  { 'dupe': true, 'type': 12, 'name': 'flexbox.gif', 'dir': 'c0', 'linked': 2, 'url': 'https://team7.ath.cx/~test/img/flexbox.gif', 'fetched': true, 'code': 200, 'len': 1520, 'decl_mime': 'image/gif', 'sniff_mime': 'image/gif', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ] }
];
