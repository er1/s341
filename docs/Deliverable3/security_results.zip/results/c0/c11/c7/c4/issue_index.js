var issue = [
  { 'severity': 3, 'type': 40304, 'extra': '', 'fetched': true, 'code': 200, 'len': 860, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' }
];
