var child = [
  { 'dupe': true, 'type': 12, 'name': 'myschedule.json', 'dir': 'c0', 'linked': 2, 'url': 'https://team7.ath.cx/~test/json/myschedule.json', 'fetched': true, 'code': 200, 'len': 0, 'decl_mime': 'application/json', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ] }
];
