var issue = [
  { 'severity': 3, 'type': 40201, 'extra': 'http://www.google.com/jsapi', 'fetched': true, 'code': 200, 'len': 3528, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10602, 'extra': '', 'fetched': true, 'code': 200, 'len': 3528, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i1' }
];
