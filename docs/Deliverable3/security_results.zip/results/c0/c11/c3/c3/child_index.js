var child = [
  { 'dupe': true, 'type': 18, 'name': 'Main.php', 'dir': 'c0', 'linked': 1, 'url': 'https://team7.ath.cx/~test/js/php/Main.php', 'fetched': true, 'code': 404, 'len': 219, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ] }
];
