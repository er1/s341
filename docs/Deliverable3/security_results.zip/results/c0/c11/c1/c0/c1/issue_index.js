var issue = [
  { 'severity': 0, 'type': 10901, 'extra': '', 'fetched': true, 'code': 200, 'len': 30906, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 30906, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'dir': 'i1' }
];
