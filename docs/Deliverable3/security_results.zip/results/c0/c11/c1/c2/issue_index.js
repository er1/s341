var issue = [
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 2873, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'dir': 'i0' }
];
